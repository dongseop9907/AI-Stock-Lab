AI STOCK LAB
v7.7.1 KRX TRADING CALENDAR OVERRIDE FIX

The original freshness guard only knew weekdays/weekends. That produced a
false STALE state on a verified weekday KRX closure.

This patch adds:
  public.market_exchange_calendar_overrides

Only verified=true overrides affect freshness.

The migration seeds:
  KRX / 2026-08-17 / is_open=false

The existing exported function name stays:
  getMarketDataFreshnessV77()

so EOD sync and all current v7.x consumers keep working without import changes.

Expected validation after install:
  expectedMarketDate = 2026-08-14
  status             = FRESH
  lag.tradingDayLag  = 0

Then EOD sync with skipIfAlreadyFresh=true should return:
  SKIPPED_ALREADY_FRESH

Unknown special closures are still fail-closed as STALE. The patch does not
infer holidays from missing bars, because a provider outage must not be
silently treated as a holiday.
