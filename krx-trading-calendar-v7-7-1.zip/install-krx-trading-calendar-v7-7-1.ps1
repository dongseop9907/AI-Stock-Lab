﻿$ErrorActionPreference = "Stop"

$root =
    "C:\Users\user\Desktop\ai-stock-lab"

$source =
    Join-Path `
        $root `
        "get-market-data-freshness-v7-7-1.patch.ts.txt"

$target =
    Join-Path `
        $root `
        "lib\market\get-market-data-freshness-v7-7.ts"

if (
    -not (
        Test-Path $source
    )
) {
    throw "SOURCE_NOT_FOUND: $source"
}

if (
    -not (
        Test-Path $target
    )
) {
    throw "TARGET_NOT_FOUND: $target"
}

$timestamp =
    Get-Date `
        -Format "yyyyMMdd-HHmmss"

$backup =
    "$target.backup-v7-7-1-$timestamp"

Copy-Item `
    $target `
    $backup `
    -Force

Copy-Item `
    $source `
    $target `
    -Force

Write-Host "BACKUP: $backup"
Write-Host "PATCHED: $target"
Write-Host ""
Write-Host "v7.7.1 KRX calendar override patch installed."
Write-Host "No route/import changes are required."
Write-Host "Existing callers still use getMarketDataFreshnessV77()."
Write-Host "Next: npx.cmd tsc --noEmit"
